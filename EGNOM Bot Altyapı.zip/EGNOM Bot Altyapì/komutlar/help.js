const Discord = require("discord.js");
const ayarlar = require("../ayarlar.json");
var PREFIX = ayarlar.prefix;
const db = require("quick.db");
exports.run = async (client, message, args) => {
  const embed = new Discord.RichEmbed()
    .setColor("PURPLE")
    .setTitle("<:egnom:757533634126151711>EGNOM » Commands By:XXFnab8<:egnom:757533634126151711>")
    .setTimestamp()
    .addField(`<a:Yldz:753578730579951637>• e!play. <a:Yldz:753578730579951637>`, `<:play:757531041438236742>play music<:play:757531041438236742>`)
    .addField(`<a:Yldz:753578730579951637>• e!stop. <a:Yldz:753578730579951637>`, `<:stop:757531097692373042>stop music<:stop:757531097692373042>`)
    .addField(`<a:Yldz:753578730579951637>• e!resume. <a:Yldz:753578730579951637>`, `<:resume:757531136514588752>resume music<:resume:757531136514588752>`)
    .addField(`<a:Yldz:753578730579951637>• e!disconnect. <a:Yldz:753578730579951637>`, `<:disconnect:757531608407605298>disconnect bot<:disconnect:757531608407605298>`)
    .addField(`<a:Yldz:753578730579951637>• e!skip. <a:Yldz:753578730579951637>`, `<:skip:757533367242588160>skip music<:skip:757533367242588160>`)
    .setFooter("© 2020  🤖EGNOM🤖")
    .setTimestamp();
  message.channel.send(embed);
};

//youtube.com/XXFnab8
//teşekkürler linlord

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["h", "help", "komutlar"],
  permLevel: 0
};

exports.help = {
  name: "help",
  description: "Tüm komutları gösterir.",
  usage: "müzik"
};
