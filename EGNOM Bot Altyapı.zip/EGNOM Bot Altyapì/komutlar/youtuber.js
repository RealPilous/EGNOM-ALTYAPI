const Discord = require("discord.js");
const ayarlar = require("../ayarlar.json");
var PREFIX = ayarlar.prefix;
const db = require("quick.db");
exports.run = async (client, message, args) => {
  const embed = new Discord.RichEmbed()
    .setColor("RED")
    .setTitle("<:egnom:757533634126151711>EGNOM » Commands By:XXFnab8<:egnom:757533634126151711>")
    .setTimestamp()
    .addField(`<a:Yldz:753578730579951637>• Creator Youtube Channel.`, `https://www.youtube.com/channel/UCD3gJhHVTHUJYAnB4po8npw?view_as=subscriberl`)
    .setFooter("© 2020  🤖EGNOM🤖")
    .setTimestamp();
  message.channel.send(embed);
};

//youtube.com/XXFnab8
//teşekkürler linlord

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["h", "help", "komutlar"],
  permLevel: 0
};

exports.help = {
  name: "youtuber",
  description: "Tüm komutları gösterir.",
  usage: "müzik"
};
